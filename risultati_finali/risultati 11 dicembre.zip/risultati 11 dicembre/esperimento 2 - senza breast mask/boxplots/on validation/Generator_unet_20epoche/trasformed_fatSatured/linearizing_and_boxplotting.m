contenuto_dir=dir;
tabella_dir = table([contenuto_dir.isdir].', {contenuto_dir.name}.', 'VariableNames', {'isdir', 'name'});
nomi_immagini=tabella_dir.name(tabella_dir.isdir==0 & tabella_dir.name~="linearizing_and_boxplotting.m" & tabella_dir.name~="linearizing_and_boxplotting.asv");
numero_immagini=size(nomi_immagini);
numero_immagini=numero_immagini(1);
%%
%or_fat=[];
%or_nofat=[];
trasf_fat=[];
%trasf_nofat=[];
for cont=1:numero_immagini
    
    im=imread(nomi_immagini{cont});
    im=im2gray(im);
    
    for i=1:size(im,2)
        %or_fat=[or_fat; im(:,i)];
        %or_nofat=[or_nofat; im(:,i)];
        trasf_fat=[trasf_fat; im(:,i)];
        %trasf_nofat=[trasf_nofat; im(:,i)];
    end   
end
%%
%elimino i pixel neri
%or_fat(or_fat==0)=[];
%or_nofat(or_nofat==0)=[];
trasf_fat(trasf_fat==0)=[];
%trasf_nofat(trasf_nofat==0)=[];
%%
figure
boxplot([or_nofat],'Notch','on','Labels',{'Original NoFat'},'Whisker',1);
set(gca, 'YGrid','on');
set(gca, 'YLim',[0 250]);
ylabel('Intensity value')
saveas(gca,'boxplot_original_nofat.pdf')
%%
figure
boxplot([or_fat],'Notch','on','Labels',{'Original Fat'},'Whisker',1);
set(gca, 'YGrid','on');
set(gca, 'YLim',[0 250]);
ylabel('Intensity value')
saveas(gca,'boxplot_original_fat.pdf')
%%
figure
boxplot([trasf_nofat],'Notch','on','Labels',{'Trasformed NoFat'},'Whisker',1);
set(gca, 'YGrid','on');
set(gca, 'YLim',[0 250]);
ylabel('Intensity value')
saveas(gca,'boxplot_trasformed_NoFat.pdf')
%%
figure
boxplot([trasf_fat],'Notch','on','Labels',{'Trasformed Fat'},'Whisker',1);
set(gca, 'YGrid','on');
set(gca, 'YLim',[0 250]);
ylabel('Intensity value')
saveas(gca,'boxplot_trasformed_Fat.pdf')